# Sanctum

Python bindings for C++ library.

## Installation

```bash
pip install sanctum